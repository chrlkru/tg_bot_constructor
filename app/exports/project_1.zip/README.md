# Опросник по Python

Бот, задающий вопросы по Python

## Как запустить бота:
```bash
pip install -r requirements.txt
python bot.py
```
