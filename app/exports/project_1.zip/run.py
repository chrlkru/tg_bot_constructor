import os
from aiogram import Bot, Dispatcher, executor
from dotenv import load_dotenv

load_dotenv()
bot = Bot(token=os.getenv('TOKEN'))
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start(msg):
    await msg.answer('Бот работает!')

if __name__ == '__main__':
    executor.start_polling(dp)
