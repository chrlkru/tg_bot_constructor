from aiogram import Bot, Dispatcher, executor, types

bot = Bot(token="8155027349:AAHy7OtruUri8DKwNq3bfcfb5z7buadlPxA")
dp = Dispatcher(bot)

questions = [{'question': 'Какой тип данных используется для хранения текста в Python?', 'options': ['int', 'float', 'str'], 'correct': 'str'}, {'question': 'Какая команда запускает цикл?', 'options': ['if', 'while', 'return'], 'correct': 'while'}]

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    for q in questions:
        options = "\n".join(f"{i+1}. {opt}" for i, opt in enumerate(q["options"]))
        await message.answer(f'{q["question"]}\n{options}')

if __name__ == '__main__':
    executor.start_polling(dp)